final String appName = 'ZuqZuq';

final String packageName = 'com.zuqzuq.user';
final String androidLink = 'https://play.google.com/store/apps/details?id=';

final String iosPackage = 'com.zuqzuq.user';
final String iosLink = 'your ios link here';
final String appStoreId = 'com.zuqzuq.user';

final String deepLinkUrlPrefix = 'https://alpha.ecommerce.link';
final String deepLinkName = 'alpha.ecommerce.link';

final int timeOut = 50;
const int perPage = 10;

final String baseUrl = 'https://developmentalphawizz.com/zuqzuq/app/v1/api/';
final String imageUrl = 'https://developmentalphawizz.com/zuqzuq/';

final String jwtKey = "e1e421dceee9ea718ab764ea4fdef95629e7f415";
